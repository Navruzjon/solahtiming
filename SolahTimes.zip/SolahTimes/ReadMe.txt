-----Solah timing in your website----

1.Import table into your database. Open your PhPMyAdmin in your Hosting>Database and import Solah.sql file;
2.Copy conn.php and parse.php into your hosting file system using Filezilla or any file manager;
3.Copy paste content of htmlcode.php into your website.
4.Fill times into solah.csv file according your time zone and insert it into your database using PhPMyAdmin in your hosting.
 The content in the file is a sample times. The column heads: date,Fajr,Iqamah,Sunrise,Dhuhr,Dhuhr_Iq,Asr,Asr_iq,Maghrib,Maghrib_iq,Isha,Isha_iq,Jumuah

That's it. May Allah SWT guide us and make us pray on time.